# ColumnRowBoxApp

Projeto Android em Kotlin + Jetpack Compose baseado no conteúdo da Aula 04 de Programação Mobile.

O projeto demonstra:
- Column para organizar elementos na vertical;
- Row para organizar elementos na horizontal;
- Box para sobreposição em camadas;
- Arrangement e Alignment;
- Spacer;
- padding;
- clip com CircleShape/RoundedCornerShape;
- weight;
- Modifier;
- @Preview;
- estado simples com remember + mutableStateOf no contador.

## Como abrir

1. Extraia o ZIP.
2. Abra a pasta `ColumnRowBoxApp` no Android Studio.
3. Aguarde o Gradle sincronizar.
4. Rode em um emulador ou celular Android.

O conteúdo foi montado a partir dos exemplos e conceitos apresentados na Aula 04: Column, Row, Box e Modifiers. fileciteturn0file0L117-L139
