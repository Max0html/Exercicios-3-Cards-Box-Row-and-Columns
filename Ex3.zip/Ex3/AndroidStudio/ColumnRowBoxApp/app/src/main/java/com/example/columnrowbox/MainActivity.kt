package com.example.columnrowbox

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFF5F7FA)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(24.dp)
                    ) {
                        // 1. Exemplo de Layout Básico (Column, Row e Box)
                        ExemploLayoutsBasicos()

                        // 2. Desafio do Ginásio: A Linha de Chat
                        DesafioLinhaDeChat()
                    }
                }
            }
        }
    }
}

@Composable
fun ExemploLayoutsBasicos() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "Exemplos de Layout",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        // Exemplo Column
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0F2B48), shape = RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Text("Column {", color = Color(0xFFFF5722), fontWeight = FontWeight.Bold)
            Text("  Text(\"A\")", color = Color.White)
            Text("  Text(\"B\")", color = Color.White)
            Text("  Text(\"C\")", color = Color.White)
            Text("}", color = Color(0xFFFF5722), fontWeight = FontWeight.Bold)
        }

        // Exemplo Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0F2B48), shape = RoundedCornerShape(8.dp))
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Row:", color = Color(0xFFFF5722), fontWeight = FontWeight.Bold)
            Text("Text(\"A\")", color = Color.White)
            Text("Text(\"B\")", color = Color.White)
            Text("Text(\"C\")", color = Color.White)
        }
    }
}

@Composable
fun DesafioLinhaDeChat() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "Ginásio de layouts — desafio 1: a linha de chat",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0F2B48)
        )

        // Item de Chat (Mockup replicado)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF0F2B48), RoundedCornerShape(8.dp))
                .background(Color.White, RoundedCornerShape(8.dp))
                .padding(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            // Avatar (Box com a letra "A")
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(Color(0xFF0F2B48), RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "A",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Nome e Mensagem
            Column(
                modifier = Modifier.weight(1f)
            ) {
                // Nome do contato
                Box(
                    modifier = Modifier
                        .width(120.dp)
                        .height(14.dp)
                        .background(Color(0xFF5A7B9A), RoundedCornerShape(2.dp))
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Mensagem
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(12.dp)
                        .background(Color(0xFFB0C4DE), RoundedCornerShape(2.dp))
                )
            }

            // Horário alinhado no topo à direita
            Text(
                text = "14:32",
                color = Color(0xFFFF5722),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
